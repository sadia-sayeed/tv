import java.util.Scanner;
import java.time.Instant; 
import java.time.Duration; 

import swiftbot.SwiftBotAPI; //for importing swiftbot APIs

import com.pi4j.util.Console;
import swiftbot.SwiftBotAPI.ImageSize;

import java.io.*;
import java.awt.image.*;
import javax.imageio.ImageIO;


public class TunnelVision {
	static SwiftBotAPI swiftBot;

	static int tunnelCounter = 0;
	static boolean[] outsideTunnel = {false, false, false};
	static boolean[] outsideTunnelConfirm = {true, true, true};
	static boolean[] intoTunnel = {false, false, false};
	static boolean[] intoTunnelConfirm = {true, true, true};
	static Instant[] tunnelEnterTimes = new Instant[3];
	static Instant[] tunnelExitTimes = new Instant[3];
	static double totalExecutionTime;
	static Duration[] timesElapsedIntoTunnels = new Duration[3];
	static Duration[] timesElapsedBetweenTunnels = new Duration[2];


	static double distanceInMilliseconds = 0.004;

	public static void main(String[] args) {
		//welcome message
		System.out.println("Welcome! ");
		try {
			swiftBot = new SwiftBotAPI(); //creating object for the SwiftBotAPI
		} catch (Exception e) {
			// Handling Unplugged robot Error.
			System.out.println("\n Error : Robot Controller is not connected");
			System.exit(0); //program terminated
		}
		final Console console = new Console();
		console.title("SwiftBot"); //giving the title
		Scanner sc = new Scanner(System.in); //creating Scanner object
		System.out.println("Type S and press Enter to continue or close the window to exit.");
		while (true) {
			System.out.println("\nUser input : ");
			String userinput = sc.next();
			System.out.println(userinput);
			try {
				if (userinput.equals("S")) {
					System.out.println("Press M for movement.");
					Scanner reader = new Scanner(System.in);
					while (true) { //user should press M to start the SwiftBot's movement
						System.out.println("\nUser input : ");
						String user_input = reader.next();
						if (user_input.equals("M")) { //SwiftBot will detect if there is any object in front of it within 0-10cm
							double object_distance = swiftBot.useUltrasound();
							if (object_distance <= 10) {
								System.out.println("Obstruction detected in front! cannot move forward.");
								System.exit(0); //object detected in front so the program will be terminated
							} else {
								try {
									swiftBot.fillUnderlights(255, 0, 0); // turning on the underlights to red
									swiftBot.startMove(30, 30); //SwiftBot's movement start
									int width = 48;
									int height = 48;
									//taken image is 48 by 48 pixels
									BufferedImage image = null;
									int i = 0;
									while (true) {
										//greyscale image to 2D array
										swiftBot.takeGrayscaleStill("/home/pi/Documents/images", "imageclicked" + Integer.toString(i + 1) + ".png", ImageSize.SQUARE_48x48, true);
										Thread.sleep(50); //frequency of taking images is 50 milliseconds

										boolean flag = true;
										File input_file = new File("/home/pi/Documents/images/imageclicked" + Integer.toString(i + 1) + ".png");
										image = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
										image = ImageIO.read(input_file);
										int[][] array = new int[width][height];
										Raster raster = image.getData();
										for (int j = 0; j < width; j++) {
											for (int k = 0; k < height; k++) {
												array[j][k] = raster.getSample(j, k, 0);
											}
										}
										for (int j = 0; j < width; j++) {
											for (int k = 0; k < 5; k++) {
												if (array[j][k] >= 90) {
													flag = false;
													break;
												}
											}
										}
										if (flag) {
											//SwiftBot is inside the tunnel
											System.out.println("In Tunnel");
											if (intoTunnel[tunnelCounter] == false) {
												intoTunnel[tunnelCounter] = true;
											}
											flag = false;
										} else {
											if (intoTunnel[tunnelCounter] == true) {
												//SwiftBot is outside the tunnel
												System.out.println("Not In Tunnel ---- !!!");
												if (outsideTunnel[tunnelCounter] == false) {
													outsideTunnel[tunnelCounter] = true;
												}
											}
										}

										if (intoTunnel[0] && intoTunnelConfirm[0]) {
											/* Inside first tunnel.
                                Proceeding with the Predetermined Algorithm to Store time in tunnelEnterTimes. */
											intoTunnelConfirm[0] = false;
											System.out.println("Entered into the first tunnel.");
											tunnelEnterTimes[0] = Instant.now();
										} else if (outsideTunnel[0] && intoTunnel[0] && outsideTunnelConfirm[0]) {
											/* Outside first tunnel.
                                Proceeding with the Predetermined Algorithm to Store time in tunnelExitTimes. */
											outsideTunnelConfirm[0] = false;
											System.out.println("Exited form first tunnel.");
											tunnelExitTimes[0] = Instant.now();
											tunnelCounter = 1;
										} else if (intoTunnel[1] && intoTunnelConfirm[1] && outsideTunnel[0]) {
											/* Inside second tunnel.
                                Proceeding with the Predetermined Algorithm to Store time in tunnelEnterTimes. */
											System.out.println("Entered into the second tunnel.");
											tunnelEnterTimes[1] = Instant.now();
											intoTunnelConfirm[1] = false;
										} else if (outsideTunnel[1] && intoTunnel[1] && outsideTunnelConfirm[1]) {
											/* Outside second tunnel.
                                Proceeding with the Predetermined Algorithm to Store time in tunnelExitTimes. */
											outsideTunnelConfirm[1] = false;
											System.out.println("Exited form second tunnel.");
											tunnelExitTimes[1] = Instant.now();
											tunnelCounter = 2;
										} else if (intoTunnel[2] && intoTunnelConfirm[2] && outsideTunnel[1]) {
											/* Inside third tunnel.
                                Proceeding with the Predetermined Algorithm to Store time in tunnelEnterTimes. */
											intoTunnelConfirm[2] = false;
											System.out.println("Entered into the third tunnel.");
											tunnelEnterTimes[2] = Instant.now();
										} else if (outsideTunnel[2] && intoTunnel[2] && outsideTunnelConfirm[2]) {
											/* Outside third tunnel.
                                Proceeding with the Predetermined Algorithm to Store time in tunnelExitTimes. */
											outsideTunnelConfirm[2] = false;
											System.out.println("Exited form third tunnel.");
											tunnelExitTimes[2] = Instant.now();

											//Time calculation
											timesElapsedIntoTunnels[0] = Duration.between(tunnelEnterTimes[0], tunnelExitTimes[0]); // Calculating time elapsed in the first tunnel.
											timesElapsedIntoTunnels[1] = Duration.between(tunnelEnterTimes[1], tunnelExitTimes[1]); // Calculating time elapsed in the second tunnel.
											timesElapsedIntoTunnels[2] = Duration.between(tunnelEnterTimes[2], tunnelExitTimes[2]); // Calculating time elapsed in the third tunnel.
											timesElapsedBetweenTunnels[0] = Duration.between(tunnelExitTimes[0], tunnelEnterTimes[1]); // Calculating time elapsed between the first tunnel and the second tunnel.
											timesElapsedBetweenTunnels[1] = Duration.between(tunnelExitTimes[1], tunnelEnterTimes[2]); // Calculating time elapsed between the second tunnel and the third tunnel.

											totalExecutionTime = timesElapsedIntoTunnels[0].toMillis() + timesElapsedBetweenTunnels[0].toMillis() + timesElapsedIntoTunnels[1].toMillis() + timesElapsedBetweenTunnels[1].toMillis() + timesElapsedIntoTunnels[2].toMillis(); //Duration of execution time.

											swiftBot.stopMove(); //stopping the SwiftBot's movement
											swiftBot.move(30, 30, 1000); //making the SwiftBot move for another 1 second
											swiftBot.fillUnderlights(0, 0, 0); //turning off the underlights

											System.out.println("Press the button ‘X’ of the SwiftBot to terminate the program.");
											while (true) {
												//user presses X to terminate
												System.out.println("\nUser input:");
												Scanner terminate = new Scanner(System.in);
												String prog_term = terminate.next();
												if (prog_term.equals("X")) {
													System.out.println("Program has been terminated. Would you like to view the log of the execution? If yes then type 'Y'. If no then type 'N'");
													while (true) {
														System.out.println("\nUser Input:");
														Scanner view = new Scanner(System.in);
														String useview = view.next();
														if (useview.equals("Y")) {
															//to view the log of execution
															System.out.println("\nThe log of execution:");
															System.out.println("\nThe length of the first tunnel, L1= " + timesElapsedIntoTunnels[0].toMillis() * distanceInMilliseconds + "cm");
															System.out.println("\nThe length of the second tunnel, L2= " + timesElapsedIntoTunnels[1].toMillis() * distanceInMilliseconds + "cm");
															System.out.println("\nThe length of the third tunnel, L3= " + timesElapsedIntoTunnels[2].toMillis() * distanceInMilliseconds + "cm");
															System.out.println("\nThe distance between the first and the second tunnel, D1= " + timesElapsedBetweenTunnels[0].toMillis() * distanceInMilliseconds + "cm");
															System.out.println("\nThe distance between the second & the third tunnel, D2= " + timesElapsedBetweenTunnels[1].toMillis() * distanceInMilliseconds + "cm");
															System.out.println("\nThe total distance travelled, F= " + totalExecutionTime * distanceInMilliseconds + "cm");
															System.out.println("\nThe duration of execution, T= " + totalExecutionTime);															
															System.out.println("Please check in the " + "imageStoreDirectory" + " for captured images.");
															System.out.println("END");
															System.exit(0); //program terminated

														} else if (useview.equals("N")) {														
															System.out.println("Please check in the " + "imageStoreDirectory" + " for captured images.");
															System.out.println("END");
															System.exit(0); //program terminated


														} else {
															System.out.println("Invalid user input. Would you like to view the log of the execution? If yes then type 'Y'. If no then type 'N'");
														}
													}
												} else {
													System.out.println("Invalid input! Press the button ‘X’ of the SwiftBot to terminate the program.");

												}
											}
										}
										i++;
									}
								} catch (Exception e) { //SwiftBot's camera is not connected
									System.out.println("\n Error : Robot Camera is not connected");
									e.printStackTrace();
									System.exit(0);
								}
							}
						} else {
							System.out.println("Incorrect input! Type M for the SwiftBot's movement.");
						}
					}
				} else {
					System.out.println("Incorrect input! Type S and press Enter to continue or close the window to exit.");
				}
			} catch (Exception e) { //invalid user input
				System.out.println("Error : Wrong user input");
			}
		}
	}
}